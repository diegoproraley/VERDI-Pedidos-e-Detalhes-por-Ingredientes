# Cadastro dos Kits — Danielli

Site com o catálogo dos kits de legumes, resumo de ingredientes por corte, e
os botões **Lançar pedido** / **Zerar produção do dia**. Sem framework — é
HTML/CSS/JS simples na raiz (`index.html`) mais funções serverless da Vercel
em `api/` que leem e gravam o estado num banco Vercel KV.

## Estrutura

```
index.html            a ferramenta inteira (interface)
api/kits.js            GET  /api/kits            -> estado atual dos kits
api/kits/lancar.js      POST /api/kits/lancar      -> soma um pedido
api/kits/zerar.js       POST /api/kits/zerar       -> zera a produção do dia
lib/seed.js             dados iniciais (só usados na primeira leitura)
lib/store.js             leitura/escrita no banco (Vercel KV)
lib/auth.js               confere a senha de administrador
```

## Como publicar (GitHub + Vercel)

**1. Suba este projeto para um repositório no GitHub**

```bash
cd danielli-kits
git init
git add .
git commit -m "Cadastro dos Kits - versão inicial"
```

Crie um repositório vazio no GitHub (github.com/new, sem README) e depois:

```bash
git remote add origin https://github.com/SEU-USUARIO/danielli-kits.git
git branch -M main
git push -u origin main
```

**2. Importe o repositório na Vercel**

- Entre em vercel.com, clique em **Add New… → Project**.
- Selecione o repositório `danielli-kits` que você acabou de criar.
- Framework: deixe em **Other** (não é Next.js nem nada parecido — a Vercel
  detecta sozinha os arquivos em `api/` como funções e o resto como estático).
- Clique em **Deploy**. Nesse primeiro deploy o site vai funcionar para
  *ver* os kits, mas os botões de escrita ainda vão dar erro — faltam os
  dois passos abaixo.

**3. Conecte um banco Vercel KV**

- No projeto, vá em **Storage → Create Database → KV** (é gratuito no plano
  Hobby, dentro do limite mensal).
- Depois de criado, clique em **Connect Project** e selecione este projeto.
  Isso preenche sozinho as variáveis `KV_REST_API_URL` e `KV_REST_API_TOKEN`.

**4. Defina a senha de administrador**

- Em **Settings → Environment Variables**, adicione:
  - Nome: `ADMIN_PASSWORD`
  - Valor: uma senha à sua escolha (é o que vai digitar no navegador para
    lançar pedidos ou zerar a produção — guarde em local seguro).
- Sem essa variável configurada, os botões de escrita ficam bloqueados por
  segurança (a consulta/leitura continua funcionando normalmente).

**5. Redeploy**

- Depois de conectar o KV e definir a senha, vá em **Deployments** e clique
  em **Redeploy** no último deploy (para as novas variáveis de ambiente
  entrarem em vigor).

Pronto — o link que a Vercel te der (algo como
`https://danielli-kits.vercel.app`) já é o site publicado, com os dados
persistindo no banco.

## Uso do dia a dia

- **Ver os kits / resumo de ingredientes**: aberto para qualquer pessoa com
  o link, sem senha.
- **Lançar pedido**: soma as quantidades informadas às que já estão em
  produção hoje (não substitui — então lançar o mesmo pedido duas vezes
  duplica a quantidade, tome cuidado).
- **Zerar produção do dia**: zera as quantidades de todos os kits (não apaga
  o cadastro — ingredientes, corte e peso por unidade continuam intactos).
  Pede confirmação antes de aplicar.
- Os dois botões de escrita pedem a senha (`ADMIN_PASSWORD`) na primeira
  vez em cada navegador/dispositivo; depois disso ficam salvos localmente
  naquele navegador.

## Atualizando o cadastro dos kits (novos produtos, ingredientes, corte)

Não tem tela para isso ainda — hoje é uma edição direta no código
(`lib/seed.js` só vale antes do primeiro acesso; depois disso o estado mora
no banco). Peça para eu (Claude) editar e sugerir o código atualizado, ou
avise se quiser que eu monte uma tela de administração para isso também.

## Rodando localmente (opcional)

Com a Vercel CLI (`npm i -g vercel`), dentro da pasta do projeto:

```bash
vercel dev
```

Isso sobe o site com as funções de API funcionando localmente (vai pedir
para linkar com o projeto na Vercel na primeira vez, para puxar as
variáveis de ambiente).
